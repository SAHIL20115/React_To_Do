import React, { useState, useEffect } from 'react';
import '../style.css';

function TodoList() {
    const [tasks, setTasks] = useState([]);
    const [archives, setArchives] = useState([]);
    const [inputValue, setInputValue] = useState('');

    useEffect(() => {
        loadTasks();
    }, []);

    const addTask = (task) => {
        setTasks([...tasks, task]);
        saveTasks([...tasks, task], archives);
    };

    const handleTaskAction = (task, action) => {
        if (action === 'delete') {
            const updatedTasks = tasks.filter(t => t !== task);
            const updatedArchives = archives.filter(t => t !== task);
            setTasks(updatedTasks);
            setArchives(updatedArchives);
            saveTasks(updatedTasks, updatedArchives);
        } else if (action === 'archive') {
            const updatedTasks = tasks.filter(t => t !== task);
            const updatedArchives = [...archives, task];
            setTasks(updatedTasks);
            setArchives(updatedArchives);
            saveTasks(updatedTasks, updatedArchives);
        } else if (action === 'unarchive') {
            const updatedArchives = archives.filter(t => t !== task);
            const updatedTasks = [...tasks, task];
            setArchives(updatedArchives);
            setTasks(updatedTasks);
            saveTasks(updatedTasks, updatedArchives);
        }
    };

    const saveTasks = (tasks, archives) => {
        localStorage.setItem('tasks', JSON.stringify(tasks));
        localStorage.setItem('archives', JSON.stringify(archives));
    };

    const loadTasks = () => {
        const savedTasks = JSON.parse(localStorage.getItem('tasks')) || [];
        const savedArchives = JSON.parse(localStorage.getItem('archives')) || [];
        setTasks(savedTasks);
        setArchives(savedArchives);
    };

    const handleInputChange = (e) => {
        setInputValue(e.target.value);
    };

    const handleAddTask = () => {
        if (inputValue.trim() !== '') {
            addTask(inputValue);
            setInputValue('');
        }
    };

    return (
        <div className="container mt-5">
            <h1 className="text-center">To-Do List</h1>
            <div className="input-group mb-3">
                <input 
                    type="text" 
                    className="form-control" 
                    value={inputValue} 
                    onChange={handleInputChange} 
                    placeholder="Add a new task" 
                />
                <div className="input-group-append">
                    <button className="btn btn-primary" onClick={handleAddTask}>Add Task</button>
                </div>
            </div>
            <ul className="list-group mb-3">
                {tasks.map((task, index) => (
                    <li key={index} className="list-group-item">
                        {task}
                        <div className="button-group">
                            <button className="archive-btn" onClick={() => handleTaskAction(task, 'archive')}>Archive</button>
                            <button className="delete-btn" onClick={() => handleTaskAction(task, 'delete')}>&times;</button>
                        </div>
                    </li>
                ))}
            </ul>
            <h2 className="text-center1">Archived Tasks</h2>
            <ul className="list-group">
                {archives.map((task, index) => (
                    <li key={index} className="list-group-item">
                        {task}
                        <div className="button-group">
                            <button className="delete-btn" onClick={() => handleTaskAction(task, 'delete')}>&times;</button>
                            <button className="unarchive-btn" onClick={() => handleTaskAction(task, 'unarchive')}>Unarchive</button>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default TodoList;
